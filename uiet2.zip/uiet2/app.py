from flask import Flask, render_template, request
import matplotlib.pyplot as plt
import os

app = Flask(__name__)

def suggest_investment(savings):
    if savings > 50000:
        return "Consider investing in Real Estate."
    elif savings > 20000:
        return "You can think about starting a SIP in a Mutual Fund."
    elif savings > 10000:
        return "You can think about starting a small SIP in a Balanced Fund."
    else:
        return "Focus on building an emergency fund before considering investments."

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/results', methods=['POST'])
def results():
    income = float(request.form['income'])
    home_expense = float(request.form['home_expense'])
    travel_expense = float(request.form['travel_expense'])
    food_expense = float(request.form['food_expense'])
    lifestyle_expense = float(request.form['lifestyle_expense'])
    other_expense = float(request.form['other_expense'])

    categories = ['Home', 'Travel', 'Food', 'Lifestyle', 'Other']
    expenses = [home_expense, travel_expense, food_expense, lifestyle_expense, other_expense]

    # Calculate total expenditure
    total_expense = sum(expenses)

    # Calculate savings
    savings = income - total_expense

    # Create a pie chart for expenses and save it as a static image
    plt.figure(figsize=(8, 6))
    plt.pie(expenses, labels=categories, autopct='%1.1f%%', startangle=140)
    plt.axis('equal')
    chart_path = 'static/pie_chart.png'
    plt.savefig(chart_path)
    plt.close()

    # Get investment suggestion based on savings
    investment_idea = suggest_investment(savings)

    return render_template('results.html', savings=savings, total_expense=total_expense, chart_path=chart_path, investment_idea=investment_idea)

if __name__ == '__main__':
    app.run(debug=True)
