from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/split', methods=['POST'])
def split():
    bill_amount = float(request.form['bill_amount'])
    number_of_persons = int(request.form['number_of_persons'])
    option = request.form['split_option']
    
    if option == 'equal':
        amount_per_person = round(bill_amount / number_of_persons, 2)
        bill_split = [amount_per_person] * number_of_persons
    else:
        percentages_key = f'person_{{i}}'
        friend_percentages = [float(request.form[percentages_key.format(i=i)]) for i in range(1, number_of_persons + 1)]
        total_percentage = sum(friend_percentages)
        if total_percentage != 100:
            return "The total percentage of all persons must be equal to 100."
        bill_split = [(round((bill_amount * percentage) / 100, 2)) for percentage in friend_percentages]

    return render_template('result.html', bill_split=enumerate(bill_split, start=1))

if __name__ == '__main__':
    app.run(debug=True)
